using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enums : MonoBehaviour
{
    public enum Path
    {
        Path1,
        Path2
    }

    public enum TowerType
    {
        Archer,
        Sword,
        Wizard
    }

    public enum SiteLevel
    {
        Onbebouwd,
        Level1,
        Level2,
        Level3
    }
}
